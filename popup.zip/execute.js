// this code will be executed when the extension's button is clicked
(function() {
  console.log('execute.js executed');
})();
